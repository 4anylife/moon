<h2 align = "center">Blockchain-based voting and reward system where users vote for trustworthy websites and earn rewards if their picks align with community consensus or performance metrics</h2>

## Setup

- Install nvm - https://github.com/coreybutler/nvm-windows/releases
- Install Node.js 20
```
nvm install 20
nvm use 20
```
- Install packages
```
npm install --legacy-peer-deps
```
- Run
```
npm run dev
```

## Some Guidelines

- In your VS Code settings, change `javascript.format.insertSpaceAfterOpeningAndBeforeClosingNonemptyBraces` to `explicit` so it won't add those spaces before and after braces
- In your VS Code settings, set `source.organizeImports` of `editor.codeActionsOnSave` to `true` to sort import automatically
- Install https://marketplace.visualstudio.com/items?itemName=heybourn.headwind to sort Tailwind CSS class automatically

## Roadmap

### 1. MVP Development

Goal: Let users vote for websites they trust
- Website submission and listing system
- User registration and wallet connection
- Token voting system (1 vote per token or quadratic voting)
- Smart contract to record votes on-chain
- UI for browsing, voting, and seeing results
- Basic leaderboard of top-voted websites

### 2. Reward Mechanism

- Define "winning" criteria (e.g., most votes, external traffic rankings, trust score)
- Smart contract for reward distribution (e.g., share prize pool with winning voters)
- Time-based voting rounds (weekly/monthly)
- Anti-cheating logic (e.g., Sybil resistance, CAPTCHA, identity attestations)
- Simple on-chain oracle integration (e.g., for Alexa Rank or other APIs)

### 3. Trust & Reputation Layer

Goal: Build credibility into the voting
- Add trust metrics to websites (e.g., HTTPS, uptime, backlinks)
- Community badges (e.g., "Most Trusted in Tech")
- Voter reputation system (score grows as users vote accurately)
- Flag/report system for fraudulent websites

### 4. Gamification & Expansion

Goal: Grow users, increase participation
- Seasonal competitions and badges
- NFT rewards for top voters
- Referral bonuses and community challenges
- DAO-based governance for rule updates
- Mobile-first dApp launch

### 5. Scaling + Ecosystem Integration

Goal: Build trust infrastructure at scale
- Multi-chain support (Polygon, Base, Solana)
- API for 3rd-party apps to use trust data
- Partnership with browsers or search engines
- Integration with DAO tooling (e.g., Snapshot or Aragon)
- Full decentralization roadmap
